# Hand Gesture Recognition Yolo v7 > 2022-08-28 6:02pm
https://universe.roboflow.com/object-detection/hand-gesture-recognition-yolo-v7

Provided by Roboflow
License: CC BY 4.0

